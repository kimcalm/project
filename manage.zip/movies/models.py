from django.db import models

# TMDB 데이터
 
class Movie(models.Model):
  TMDB_pk = models.IntegerField()
  title_en = models.CharField(max_length=100)
  title_kr = models.CharField(max_length=100)
  release_date = models.DateField()
  genre_ids = models.TextField()
  poster_path = models.TextField()
  overview = models.TextField()
  vote_average = models.IntegerField()