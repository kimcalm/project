from rest_framework import serializers
from .models import Movie, Tmdb_Movie

class MovieSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tmdb_Movie
        fields = '__all__'

# class MovieListSerializer(serializers.ModelSerializer):
#     id = MovieSerializer(id, read_only='poster_path')

#     class Meta:
#         model = Movie
#         # fields = ('poster_path', 'movieNm', 'prdtYear', 'nations',)
#         fields = ('id', 'movieNm', 'prdtYear', 'nations',)

class MovieListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tmdb_Movie
        fields = ('id', 'overview',)
