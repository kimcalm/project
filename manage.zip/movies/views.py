from django.shortcuts import render

from rest_framework.response import Response
from rest_framework.decorators import api_view

from .models import Movie, Tmdb_Movie
from .serializers import MovieListSerializer, MovieSerializer

@api_view(['GET'])
def movie_list(request):
    movies = Movie.objects.all()
    serializer = MovieListSerializer(movies, many=True)
    return Response(serializer.data)

@api_view(['GET'])
def movie_detail(request, movie_pk):
    movie = Tmdb_Movie.objects.get(movie_id=movie_pk)
    serializer = MovieSerializer(movie)
    return Response(serializer.data)